# Project 3, Final Submission: Design Journey

> **Replace ALL _TODOs_ with your work.** (There should be no TODOs in the final submission.)
>
> Be clear and concise in your writing. Bullets points are encouraged.
>
> Place all design journey images inside the "design-plan" folder and then link them in Markdown so that they are visible in Markdown Preview.
>
> **Everything, including images, must be visible in _Markdown: Open Preview_.** If it's not visible in the Markdown preview, then we can't grade it. We also can't give you partial credit either. **Please make sure your design journey should is easy to read for the grader;** in Markdown preview the question _and_ answer should have a blank line between them.


## Milestone 1 Feedback Revisions
> Explain what you revised in response to the Milestone 1 feedback (1-2 sentences)
> If you didn't make any revisions, explain why.

complaints were made regarding my interaction diagrams. I have made changes to the interactivity anyway, and as such have created two new diagrams for interactivity of the modal in milestone one.


## Interactivity Usability Justification
> Explain how the interactivity _functionally_ improves the user's experience and helps them accomplish their goals. (i.e. Your interactivity does _more_ than add additional clicks; the interactivity doesn't insert additional barriers for the user when working towards their goals.)
> Explain how your interactivity's design effectively uses affordances, visibility, feedback, and familiarity.
> Write a paragraph (3-4 sentences)

My website is designed for simulator pilots of different skill levels. Some pilots may be coming from other aircraft, and as such they are already familiar with the basic tactics of "notching" which is what the modal diagrams. As such, content such as how to conduct within visual range combat is drastically more important to them, and so having a massive diagram that they need to scroll past slows down how quickly they can get to the content. Specifically, if they need to access the information quickly while flying the plane, it is extra important that they can do so quickly. Consequently, it makes sense to hide the diagram, and have an option to show it for those who may need more explanation of basic concepts.


## Tell Us What to Grade
> We aren't re-grading your entire Project 1 or 2.
> We are only grading the interactivity you added to the project.
> Tell us where (what pages) we can find your interactivity and how to use it.
> **We will only grade what you list here;** if it's not listed here, we won't grade it. **No exceptions.**

Interactivity was added in the form of the Hamburger menu (this is visible on every page, with the only difference being the links displayed. There is no home link on the home page for example, but there is on the operations page).

This is usable when the page is below 900px in width, and can be used by clicking on images/Menu.jpg

The modal is on the "combat operations page" (operations.html) and can be accessed by clicking on the white box with the downwards pointing arrows in the "Defensive Tactics" section: images/click_me.png

The modal displays a popup which overlays on top of the page, and can be closed by clicking the red X in the top corner (close.jpg)


## Self-Reflection
> Reflect on what you learned during this assignment. How have you improved from Project 1? What would you do differently next time? (2-3 sentences)

Taking project one which had no interactivity, and adding interactivity to better suit navigation menus for different page widths as well as adding popup content was definitely a large learning part of project 3. However, I would next time probably make the popup size itself dynamically based on the page size so that it says in proportion better with the area it is covering.

> Take some time here to reflect on how much you've learned since you started this class. It's often easy to ignore our own progress. Take a moment and think about your accomplishments in this class. Hopefully you'll recognize that you've accomplished a lot and that you should be very proud of those accomplishments! (1-3 sentences)

The interactivity is something that is pretty cool, and it's definitely a neat feature, particularly in the context of a hamburger menu for mobile devices.

## References

### Collaborators
> List any persons you collaborated with on this project.

None.


### Reference Resources
> Did you use any resources not provided by this class to help you complete this assignment?
> List any external resources you referenced in the creation of your project. (i.e. W3Schools, StackOverflow, Mozilla, etc.)
>
> List **all** resources you used (websites, articles, books, etc.), including generative AI.
> Provide the URL to the resources you used and include a short description of how you used each resource.

None.
