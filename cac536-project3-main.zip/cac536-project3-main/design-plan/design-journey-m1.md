# Project 3, Milestone 1: Design Journey

> **Replace ALL _TODOs_ with your work.** (There should be no TODOs in the final submission.)
>
> Be clear and concise in your writing. Bullets points are encouraged.
>
> Place all design journey images inside the "design-plan" folder and then link them in Markdown so that they are visible in Markdown Preview.
>
> **Everything, including images, must be visible in _Markdown: Open Preview_.** If it's not visible in the Markdown preview, then we can't grade it. We also can't give you partial credit either. **Please make sure your design journey should is easy to read for the grader;** in Markdown preview the question _and_ answer should have a blank line between them.


## Project
> Which project will you add interactivity to enhance the site's functionality?

Project 1


## Audience's Goals
> List the audience's goals that you identified in Project 1 or 2.
> Simply list each goal. No need to include the "Design Ideas and Choices", etc.
> You may adjust the goals if necessary.

- Learn about the offensive systems of the F-14

- Learn about the defensive systems of the F-14

- Learn how to utilize both offensive and defensive systems in a complex enviroment to combat hostile aircraft

## Modal Interactivity Brainstorm
> Using the audience goals you identified, brainstorm possible options for **modal** interactivity to enhance the functionality of the site while also assisting the audience with their goals.
> Briefly explain each idea and provide a brief rationale for how the interactivity enhances the site's functionality for the audience. (1 sentence)
> Note: You may find it easier to sketch for brainstorming. That's fine too. Do whatever you need to do to explore your ideas.

- My first idea is to add a popup to show images that essentially show diagrams of the tactics that are being discussed on the operations.html page, particularly to the dicussion on notching. This would help the audience visualize the tactics, making them easier to learn.
- My second idea is to create a popup to present additional technical data for the RWR on the defensive_systems.html page. This will give more in depth information to advanced players who may want it.

## Interactivity Design Ideation
> Explore the possible design solutions for the interactivity.
> Sketch at least two iterations of the modal and at least two iterations of the hamburger menu interactivity.
> Annotate each sketch explaining what happens when a user takes an action. (e.g. When user clicks this, something else appears.)
> Do not include HTML/CSS annotations in your sketches!

![](Modal_1.jpg)

![](Modal_2.jpg)

![](Menu_1.jpg)

![](Menu_2.jpg)

## Final Interactivity Design Sketches
> Create _polished_ design sketch(es) (it's still a sketch, but with a little more care taken to communicate ideas clearly to the graders) to plan your interactivity.
> **Sketch out the entire page where your interactivity will go.**
> Include your interactivity to the sketch(es).
> Add annotations to explain what happens when the user takes an action.
> Include as many sketches as necessary to communicate your design (ask yourself, could another 1300 take these sketches an implement my design?)

**Modal design sketches:**

![](closed.jpg)

![](opened.jpg)

**Hamburger drop-down navigation menu design sketches:**

![](Menu_Final.jpg)

## Interactivity Rationale
> Describe the purpose of your proposed interactivity.
> Provide a brief rationale explaining how your proposed interactivity addresses the goals of your site's audience.
> This should be about a paragraph. (2-3 sentences)


With regards to the menu, it condenses the navigation to a size that is more appropiate for smaller screens, thus improving usability, particularly on phone screens. With regards to my modal design, the pop up diagrams that I intend to implement will provide a visual representation of the concepts that I am explaining in the text. This will both clarify the concept, as well as provide an alternative way of understanding the material for visitors who may be more of a visual learner, thus helping to accomodate different learners.


## Interactivity Planning Sketches
> Produce planning sketches that include all the details another 1300 student would need to implement your interactivity design.
> Your planning sketches should include _all_ HTML elements needed for the interactivity; _annotations_ for the element types, their unique IDs, and CSS classes; and lastly the initial CSS classes.
> This is asking you to create a planning sketch like the one we did during the in-class activity.

**Modal planning sketches:**

![](Modal_Technical.jpg)

**Hamburger drop-down navigation menu planning sketches:**

![](Menu_Technical.jpg)


## Interactivity Pseudocode Plan
> Write your interactivity pseudocode plan here.
> Pseudocode is not JavaScript. Do not put JavaScript code here.

**Modal pseudocode:**

> Pseudocode to open the modal:

```
When #Interaction_Button is clicked
  add .hidden to #Radar
  add .hidden to #BVR
  add .hidden to #WVR
  remove .hidden from #Popup
```
Note: Interaction_Button will be contained within #WVR


Modified to:
When #Interaction_Button is clicked
  remove .hidden from #Popup


> Pseudocode to close the modal:

```
When #Closing_Button is clicked
  Add .hidden from #Popup
  Remove .hidden to #Radar
  Remove .hidden to #BVR
  Remove .hidden to #WVR
```
Note: Closing Button is contained within #Popup

Modified to:
When #Interaction_Button is clicked
  add .hidden to #Popup

**Hamburger menu pseudocode:**

> Pseudocode to show/hide (toggle) the navigation menu (narrow screens) when the hamburger button is clicked:

```
when the hamburger button is clicked:
  if the navigation menu is not visible:
    #Remove .hidden from #Home_Link_Narrow
    #Remove .hidden from #Offense_Link_Narrow
    #Remove .hidden from #Defense_Link_Narrow
    #Remove .hidden from #Operations_Link_Narrow

  else:
    #Add .hidden from #Home_Link_Narrow
    #Add .hidden from #Offense_Link_Narrow
    #Add .hidden from #Defense_Link_Narrow
    #Add .hidden from #Operations_Link_Narrow
```

> Media queries are prohibited to show/hide the hamburger menu for this assignment.
> (I want you to demonstrate the interactivity learning objectives we covered in class.)
> If the browser window is narrow when the page loads, the hamburger button should be visible and the navigation should be hidden.
> If the browser window is wide when the page loads, the hamburger menu should not be visible.
> Complete the pseudocode to show/hide (toggle) the navigation on page load:

```
on page load (ready):
  if window is narrow:
    Add .hidden to #Nav_Wide
    Remove .hidden from #Menu
   else if window is wide:
```
No code should be needed if page is wide, since that is default state the page is setup for.

> If the browser window is resized from wide to narrow, the hamburger menu should become visible and the navigation should be hidden.
> If the browser window is resized from narrow to wide, the hamburger menu should become hidden and the navigation should be visible.

```
on window resize:
  if window is narrow:
    Add .hidden to #Nav_Wide
    Remove .hidden from #Menu
  else if window is wide:
    Add .hidden to #Menu
    Remove .hidden from #Nav_Wide
```


## References

### Collaborators
> List any persons you collaborated with on this project.

None.

### Reference Resources
> Did you use any resources not provided by this class to help you complete this assignment?
> List any external resources you referenced in the creation of your project. (i.e. W3Schools, StackOverflow, Mozilla, etc.)
>
> List **all** resources you used (websites, articles, books, etc.), including generative AI.
> Provide the URL to the resources you used and include a short description of how you used each resource.

None.
